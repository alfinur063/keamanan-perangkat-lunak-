<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a><?php /**PATH C:\xampp\htdocs\laravel_register\resources\views/sb-admin/button-topbar.blade.php ENDPATH**/ ?>