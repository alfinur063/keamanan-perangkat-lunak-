 <script>
    if (window.innerWidth <= 575) {
        var element = document.getElementById("main");
        element.classList.remove("show");
    }
</script>