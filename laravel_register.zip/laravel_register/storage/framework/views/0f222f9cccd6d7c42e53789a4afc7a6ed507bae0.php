<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a><?php /**PATH C:\xampp\htdocs\laravel_8_blog-master\resources\views/sb-admin/button-topbar.blade.php ENDPATH**/ ?>